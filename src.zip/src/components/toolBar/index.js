import toolBar from '@/components/toolBar'
export default{
  install(Vue) {
    Vue.component(toolBar.name,toolBar)
  }
}